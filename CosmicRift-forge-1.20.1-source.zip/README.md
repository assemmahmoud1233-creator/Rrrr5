# Cosmic Rift (Forge 1.20.1)
## البناء أونلاين
1. اعمل Repository جديد على GitHub وارفع كل محتوى المجلد (لازم فولدر .github يترفع).
2. افتح تبويب Actions ← "Build mod" ← Run workflow (أو هيشتغل لوحده بعد الرفع).
3. بعد ما يخلص، افتح التشغيلة ونزّل Artifact اسمه CosmicRift-jar. جواه ملف الـ jar.
4. حطه في فولدر mods بتاع ماين كرافت Java مع Forge 1.20.1.
## الأوامر (OP)
/cosmic meteor  /cosmic supernova  /cosmic rift
