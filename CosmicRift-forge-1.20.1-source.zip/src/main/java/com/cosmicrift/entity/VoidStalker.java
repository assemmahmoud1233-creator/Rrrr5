package com.cosmicrift.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.Level;

/** Tall teleporting shadow with a purple aura (enderman-based). */
public class VoidStalker extends EnderMan {
    public VoidStalker(EntityType<? extends EnderMan> type, Level level) {
        super(type, level);
        this.xpReward = 30;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return EnderMan.createAttributes()
                .add(Attributes.MAX_HEALTH, 100.0D)
                .add(Attributes.ATTACK_DAMAGE, 9.0D);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            for (int i = 0; i < 2; i++) {
                this.level().addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                        this.getRandomX(0.8), this.getRandomY(), this.getRandomZ(0.8), 0, 0.02, 0);
            }
            this.level().addParticle(ParticleTypes.PORTAL,
                    this.getRandomX(1.0), this.getRandomY() - 0.25, this.getRandomZ(1.0), 0, 0, 0);
        }
    }
}
